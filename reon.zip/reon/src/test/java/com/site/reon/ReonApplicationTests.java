package com.site.reon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReonApplicationTests {

	@Test
	void contextLoads() {
	}

}
