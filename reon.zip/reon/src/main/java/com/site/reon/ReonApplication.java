package com.site.reon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReonApplication.class, args);
	}

}
